from cis301.phonebill.abstract_phonecall import AbstractPhoneCall


class PhoneCall(AbstractPhoneCall):
    pass