from cis301.phonebill.phonebill_parser import PhoneBillParser


class TextParser(PhoneBillParser):
    pass