from cis301.phonebill.abstract_phonebill import AbstractPhoneBill


class PhoneBill(AbstractPhoneBill):
    pass